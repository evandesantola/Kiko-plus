#include <time.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
int a[1000000];

void swap(int* someList, int i, int j) {
	int tmp = someList[i];
	someList[i] = someList[j];
	someList[j] = tmp;
}

int partition(int* someList, int length, int leftIndex, int rightIndex, int pivot) { 
     
     int pV = someList[pivot];
     swap(someList, pivot, rightIndex);
     int j = leftIndex;
     for (int i= leftIndex; i< rightIndex; i++) {
	if (someList[i] < pV) {
	   swap(someList, i, j);
	   j++;
        }
     }
     swap(someList,rightIndex, j);
     return j;
}

int quickSelect(int* someList, int length, int k) {
    int l = 0;
    int r = length - 1;
    srand(time(NULL));
    while (r >= l) {
        int pivot = partition(someList, length, l, r, l+(rand()%(r+1-l))); 
        if (pivot > k) {
           r = pivot - 1; 
        } else if (pivot < k) {
           l = 1 + pivot;
        } else {
           return pivot;
        }
    }
    return -1;
}

int main(){
	int i, n;
	scanf("%d", &n);
	for(i=0;i<n;i++) scanf("%d", &a[i]);

	int* someList = calloc(n, sizeof(int));


	for(i=0;i<n;i++) {
		someList[i] = a[i];
         }
	int k = log(n)/log(2);
	int kInit = k;
	printf("%d\n", k);
	int* toPrint = calloc(k+1, sizeof(int));
	while (k != (0-1)) {
//printf("Finding kth largest for k=%d", (1<<k)-1);
	        int kthLargestIdx = quickSelect(someList, n, (1<<k) - 1);
		
		toPrint[k]=  someList[kthLargestIdx];	
		n = partition(someList, n, 0, n-1, kthLargestIdx);
//		printf("Partion returned %di\n", n);
//		printf("List is now: \n");
//		for (int p=0; p<n; p++) {
//			printf("p:%d\n", someList[p]);
//		}
		k--;
	
	}
	for (i=0; i<= kInit; i++) {
	   printf("%d%c", toPrint[i], i == kInit ? '\n' : ' ');
	}
	return 0;
}
